from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time
from selenium.webdriver.chrome.options import Options
chrome_options = Options()
chrome_options.add_experimental_option("detach", True)
username = "littlepink.lp1@gmail.com"
password = "0882261979pink"
concert_name="Young K Solo Concert"
seat = 1
zone = "RE-L"
driver = webdriver.Chrome(options=chrome_options)
driver.get('https://www.thaiticketmajor.com/concert/')
accept = driver.find_element(By.XPATH,'/html/body/div[3]/div/div/div[2]/button').click()
login = driver.find_element(By.XPATH,'/html/body/div[1]/header/div[1]/div/div[3]/div/button')
login.click()
time.sleep(1)
user = driver.find_element(By.XPATH,'//*[@id="frm-signin"]/div[2]/div/div[1]/input')
pas = driver.find_element(By.XPATH,'//*[@id="frm-signin"]/div[2]/div/div[2]/div/input')
user.send_keys(username)
pas.send_keys(password + Keys.ENTER)
time.sleep(1)
con = driver.find_element(By.PARTIAL_LINK_TEXT, concert_name)
con.click() 
buy_ticket = driver.find_element(By.XPATH,'//*[@id="section-event-round"]/div/div[1]/div[3]/div[2]/div/div[2]/span')
buy_ticket.click()
x =  len(driver.find_elements(By.XPATH,'//*[@id="btn_verify"]'))
print(x)
if x == 1:
     driver.find_element(By.CLASS_NAME, "label-txt").click()
     time.sleep(1)
     driver.find_element(By.XPATH,'//*[@id="btn_verify"]').click()
else:
     pass
jobs_link = driver.find_element(By.CSS_SELECTOR, f"[href='#fixed.php#{zone}']").click()
# driver.find_element(By.CSS_SELECTOR, f"[href='#festival.php#{zone}']").click()
row = len(driver.find_elements(By.XPATH,'//*[@id="tableseats"]/tbody/tr'))
count = 0
for i in range(1,row+1):
    column=len(driver.find_elements(By.XPATH,f'//*[@id="tableseats"]/tbody/tr[{i}]/td'))
    for j in range(2,column+1):
        text=driver.find_element(By.XPATH,f'//*[@id="tableseats"]/tbody/tr[{i}]/td[{j}]').text
        if text=="":
            print("seats: not available")
        if text!=" " and count<seat and text!="":
            driver.find_element(By.XPATH,f'//*[@id="tableseats"]/tbody/tr[{i}]/td[{j}]').click()
            count+=1
        if count==seat:
            break
    if count==seat:
            break
# close = driver.find_element(By.PARTIAL_LINK_TEXT, "Close")
# close.click()
driver.find_element(By.XPATH,'//*[@id="booknow"]').click()